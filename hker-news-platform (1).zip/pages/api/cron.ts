
// [DELETED]
// Switched to Vercel Native Serverless Function at /api/cron.js
// This file is removed to avoid routing conflicts.
export default function handler(req, res) {
  res.status(404).json({ error: "Route moved to /api/cron.js (Vercel Native)" });
}
